%clear all
%close all
%clc

%% load all the data necessed, and add the correct paths
setup

path_image_forged = 'dataset/dev-dataset-forged/';
path_image_map = 'dataset/dev-dataset-maps/';
path_tmp = 'tmp/';

dataset = dir('dataset/dev-dataset-forged/');
maps = dir('dataset/dev-dataset-maps/');

% need to change the camera folder
camera{1} = load('data/camera_models/camera1');
camera{2} = load('data/camera_models/camera2');
%i discard those camera because the model is not correct and the result are
%dirty

%camera{3} = load('data/camera_models/camera3');
%camera{4} = load('data/camera_models/camera4');

%% star analizing all the images

noise_sigma = 3.0;

if exist('lista.mat')
    load('lista');
else
    lista_calcoli = cell(1, 23);
    save('lista', 'lista_calcoli');
end





for i = 461 : numel(dataset)
    
    if dataset(i).isdir == 0
        
        name_gg = [path_image_forged dataset(i).name];
        
        disp(['computing image: ' name_gg]);
        result_name = get_map(name_gg);
        
        
        
        
        %{
        
        disp(['computing image: ' num2str(i)]);
        col = 1;
        image = imread([path_image_forged dataset(i).name]);
        map_real = imread([path_image_map maps(i).name]);
        
        %somethime happens that read 4 channel so we delete the 4th
        [ n, m, volume] = size(image);
        if volume == 4
           im_nuova(:, :, 1) = image(:, :, 1);
           im_nuova(:, :, 2) = image(:, :, 2);
           im_nuova(:, :, 3) = image(:, :, 3);
           image = im_nuova;
        end
        
        
        list_corr = zeros(1,4);
        
        %find the correspondence of the camera if exist
        
        
        
        
        %extraxt the first noise
        noise = NoiseExtractFromImage(image, noise_sigma);
        noise = ZeroMeanTotal(noise);
        noise = WienerInDFT(noise, std2(noise));
        
        image2 = double(rgb2gray(image));
        
        %find the most suitable correlation 
        for pr = 1 : numel(camera)
            prnu = rgb2gray1(camera{pr}.camera_model.prnu);
            prnu = WienerInDFT(prnu,std2(prnu));
            prnu = prnu .* image2;
            list_corr(pr) = corr2(prnu, noise);
        end
        [max_corr, max_ind] = max(list_corr(:));
        lista_calcoli{i, col} = [path_image_forged dataset(i).name]; col = col+1;
        lista_calcoli{i, col} = max_corr; col = col+1;
        lista_calcoli{i, col} = max_ind; col = col+1;
        
        lista_calcoli{i, 9} = 0;
        
        
        
        %fix some parameter
        w = [30, 2.5];
        threshold = 0.4;
        
        if max_corr > 0.01
            windows = [97 129 193 257];
            resp = cell(1, numel(windows));
            
            for win = 1 : numel(windows)
                %calculate all the map needed for the fusion part
                result_itermediate  = detectForgeryPRNUCentral(image, camera{max_ind}.camera_model, windows(win), ...
                    struct('verbose', true, 'stride', 8, 'image_padding', true));
                resp{win}.candidate = result_itermediate.map_prp;
                %onece you get the map you calculate the reliability
                resp{win}.reliability = 1 - exp(-abs(w(1)*(resp{win}.candidate - 0.5).^w(2)));
                
                
            end
            %valori aggiustati della fuse
            fusion_labeling = fuseCRF(resp, image, 0.4, [-1 0.7 6.6 25 0.18]);
            %fusion_labeling = fuseCRF(resp, image, threshold, [-1 0.5 5.6 25 0.18]);
            
            f1_mesure = f_measure(imresize(fusion_labeling, [1500 2000]), map_real);
            
            ottimal_result = detectForgeryPRNUCentral(image, camera{max_ind}.camera_model, 257, ...
                struct('verbose', true, 'stride', 8, 'segmentwise_correlation', true, 'image_padding', true));
            
            imm1 = ottimal_result.map_prp > 0.4;
            
            %meglio seconda treshold
            imm2 = ottimal_result.map_prp > 0.5;
            
            f1_mesure1 = f_measure(imresize(imm1, [1500 2000]), map_real);
            f1_mesure2 = f_measure(imresize(imm2, [1500 2000]), map_real);
            
            lista_calcoli{i, 1} = [path_image_forged dataset(i).name];
            lista_calcoli{i, 2} = max_corr;
            lista_calcoli{i, 3} = max_ind;
            lista_calcoli{i, 4} = fusion_labeling;
            lista_calcoli{i, 5} = resp;
            lista_calcoli{i, 6} = f1_mesure;
            lista_calcoli{i, 7} = ottimal_result;
            lista_calcoli{i, 8} = f1_mesure1;
            lista_calcoli{i, 9} = f1_mesure2;
            
        else
            % here must go the part of jpeg detection
            %im working on it
            
        end
        
        
        
        % part of testing jpeg
        
        
        name = dataset(i).name;
        name = strsplit(name, '.');
        extension = name{numel(name)};
        main_name = '';
        QF = 85;
        col = 10;
        name_image = '';
        
        for t = 1:(numel(name)-1)
            main_name = [main_name name{t}];
        end
        if ~strcmp(extension, 'jpg')
            name_image = [path_tmp main_name '.jpg'];
            imwrite(image, name_image, 'Quality', QF);
            
        else
            name_image = [path_image_forged dataset(i).name];
        end
        
        im = jpeg_read(name_image);
        [LLRmap, LLRmap_s, q1table, alphat] = getJmap_EM(im, 1, 6);
        map_final = imfilter(sum(LLRmap,3), ones(3), 'symmetric', 'same');
        
        fin = map_final < -45;
        
        f1_m = f_measure(imresize(fin, [1500 2000]), map_real);
        
        
        lista_calcoli{i, col} = f1_m; col = col+1;
        lista_calcoli{i, col} = sum(fin(:) == 1); col = col+1;
        
        fin = fin < 1;
        f1_m = f_measure(imresize(fin, [1500 2000]), map_real);
        lista_calcoli{i, col} = f1_m; col = col+1;
        lista_calcoli{i, col} = sum(fin(:) == 1); col = col+1;
        
        
        [counts,x] = imhist(map_final,16);
        tr = otsuthresh(counts);
        BW = imbinarize(map_final, tr);
        
        f1_m = f_measure(imresize(BW, [1500 2000]), map_real);
        lista_calcoli{i, col} = f1_m; col = col+1;
        lista_calcoli{i, col} = sum(BW(:) == 1); col = col+1;
        
        BW = BW < 1;
        f1_m = f_measure(imresize(BW, [1500 2000]), map_real);
        lista_calcoli{i, col} = f1_m; col = col+1;
        lista_calcoli{i, col} = sum(BW(:) == 1); col = col+1;
        
        
        col = 18;
        % CFA correlation
        bayer = [0, 1; 1, 0];
        possi{1} = [2, 2];
        possi{2} = [8, 1];
        possi{3} = [8, 2];
        
        for comb = 1:numel(possi)
            try
                [map, stat] = CFAloc(image, bayer, possi{comb}(1), possi{comb}(2));
                fir = map < 0;
                f1_m = f_measure(imresize(fir, [1500 2000]), map_real);
                lista_calcoli{i, col} = sum(fir(:) == 1); col = col+1;
                lista_calcoli{i, col} = f1_m; col = col+1;
            catch
                 col = col+1;  col = col+1;
            end
        end
        
        
        save('lista', 'lista_calcoli');
        %}
    end
end
