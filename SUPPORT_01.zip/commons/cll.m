set(gca, 'XTick', []);
set(gca, 'YTick', []);